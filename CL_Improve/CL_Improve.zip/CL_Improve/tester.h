#define CL_IMPROVE_EXPORT
#include "TestProgApp/Public.h"
#include <afxwin.h>

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <io.h>
#include <iomanip>
#include <string.h>
#include <hash_map>
#include "TestTimer.h"
using namespace std;
#include "CL_Improve.h"
#include "Sharing_inside.h"

static ofstream fileout;

