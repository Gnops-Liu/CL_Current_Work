Pointers about using Developer Studio for writing test programs
---------------------------------------------------------------

Different views are available using the tabs in the left hand pane:
	Class View
	File View
	Info View
You will be working in File View when coding your test program.

Inserting new files into your project:
	Create a new file under the File pull-down with "New".
	Save the file using "Save As" under the File pull-down.
	Under the Insert pull-down, select "Files Into Project"
	Type the name of the file, and click "Add" in the dialog
		box (or double click the file you want).

Deleting files from your project:
	In File View mode, select the file and hit the delete key.

Building your program:
	Hit F7 (or use the Build pull-down menu).

Running your program:
	Hit F5 (or choose Debug under the Build pull-down menu).
