// ****************************************************************
// ***** PINLIST and PE Board List External Declarations file *****
// ****************************************************************
//
//*****************************************************

EXTERN_PINLIST(pl_CLK)
EXTERN_PINLIST(pl_SDA)
EXTERN_PINLIST(pl_all_pins)
EXTERN_PINLIST(pl_DVDD_1P5)
EXTERN_PINLIST(pl_RESET)
EXTERN_PINLIST(pl_TST)
EXTERN_PINLIST(pl_VCC)
EXTERN_PINLIST(pl_VPP)
EXTERN_PINLIST(pl_VNN)
EXTERN_PINLIST(pl_dps)
EXTERN_PINLIST(pl_dpo)
EXTERN_PINLIST(pl_dpohv)
EXTERN_PINLIST(pl_hv)
EXTERN_PINLIST(pl_VDD15)
EXTERN_PINLIST(pl_ebm_dma_write_l);
EXTERN_PINLIST(pl_ebm_dma_write_f);