__declspec(dllexport) void initcntr();
__declspec(dllexport) void startcntr();
__declspec(dllexport) void startseqcntr();
__declspec(dllexport) void startpattimer();
__declspec(dllexport) double stopcntr();
__declspec(dllexport) double stopseqcntr();
__declspec(dllexport) double stoppattimer();

