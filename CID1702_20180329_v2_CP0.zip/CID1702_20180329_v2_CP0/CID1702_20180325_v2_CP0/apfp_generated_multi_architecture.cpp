// This file was automatically created and added to your project by apfp
// to support compiling patterns for multiple platforms.
// It was created on Mon Oct 23 16:11:41 2017
//
// This file allows a single test program to contain APG patterns
// compiled for different architectures.
// See Libraries\Include\multi_architecture.h for more information.
//
#define PATCOM_OUTPUT
#include "tester.h"
#undef PATCOM_OUTPUT
#include "multi_architecture.h"

// This patcom-generated super-includes #includes every patcom-generated .h file.
#include "patcom_generated_includes.h"

