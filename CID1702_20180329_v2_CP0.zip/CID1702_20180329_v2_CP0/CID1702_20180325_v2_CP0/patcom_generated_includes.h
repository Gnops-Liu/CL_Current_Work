// This file is automatically maintained by patcom, and was last updated on 10:10:15 04/03/18.
//
// Feel free to comment out individual lines if that suits your purposes.
// If you use C++ style comments (like this one), then they will be preserved.

#ifndef PATCOM_OUTPUT
#include "SubPattern_MAG2.h"
#include "Trim_MAG2.h"
#endif
