// This file is automatically maintained by patcom, and was last updated on 11:15:14 05/22/18.
//
// Feel free to comment out individual lines if that suits your purposes.
// If you use C++ style comments (like this one), then they will be preserved.

#ifndef PATCOM_OUTPUT
#endif
