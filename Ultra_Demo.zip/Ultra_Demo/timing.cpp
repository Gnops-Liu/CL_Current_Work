#include "tester.h"


//// Setup timing functions 
//void ts_20_Mhz() { // 20 Mhz   T=50NS
//	cycle(	TSET1,  50 NS);
//	settime(TSET1,	pl_crtl,			NRZ, 0 NS);
//	settime(TSET1,  pl_sclk,			RTZ, 25 NS, 50 NS);
//	settime(TSET1,	pl_eflash_inputs,	NRZ, 0 NS);
//	settime(TSET1,  eFlash_sio_i,		NRZ, 0 NS);
//	settime(TSET1,	pl_pmu_inputs,		NRZ, 0 NS);
//	settime(TSET1, pl_eflash_outputs, STROBE, 25 NS, 25 NS);
//}

